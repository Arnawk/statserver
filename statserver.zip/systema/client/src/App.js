import React, { Component } from "react";
import './App.css';
class App extends Component {

	
	state={
		nums:"",
		mean:0.0,
		median:0,
		variance:0.0,
		stddev:0.0,
		error:"",
	
	};
	componentDidMount() {
    this.getRandomNumbers();
    
    }
  

  // never let a process live forever
  // always kill a process everytime we are done using it
  componentWillUnmount() {
   
  }
getRandomNumbers = () => {
	fetch('http://104.197.1.160:3000/api/genRand')
		.then(response => {
       if(response.ok){
       return response.json();
      }else{
      throw new Error('Something went wrong...')
    }
 })
  .then(data => this.setState({
    nums: data.nums
  }))
  .then(data => document.getElementById("allNumbers").value = data.nums)
  .catch(error => this.setState({
     error: 1
  }))
};

checkSanity = (req) => fetch('http://104.197.1.160:3000/api/checkSanity?allNums='+req)
.then(response=>{
if(response.ok){
return response.json();
}
})
.then(data=> this.setState({
	error: data.error
}))
getStats = (req) => {

	if (this.state.error === 'all okay!')
	fetch('http://104.197.1.160:3000/api/calculateStats?allNums='+req)
	.then(response=>{
	if(response.ok){
	return response.json();
	}
	})
	.then(data => this.setState({
		mean: data.mean,
		median: data.median,
		variance: data.variance,
		stddev: data.stddev
	}))


};
	
render() {
	const {nums, mean, median, variance, stddev, error}=this.state;
    return (
    <div>
<div className="InputBar">
<div>
<h1>Enter List</h1>
<input className="allNumbers" name="allNumbers" type="text" id="allNumbers" defaultValue={nums} onChange={()=>this.checkSanity(document.getElementById('allNumbers').value)} />


</div>


<div>

  
  <p className="helpText">Enter comma separated list of numbers.</p>

  <input className="calculateButton" type="button" value="Calculate Statistics" onClick={() => this.getStats(document.getElementById('allNumbers').value)} /> 
  
  <input className="generateRandomButton"  name="randomGenerator" type="button" value="Generate Random Numbers" onClick={() => this.getRandomNumbers()} />

</div>




  
  </div>

<div  className="output">
  <hr />

  <code>
  	<br />
  	Original Data : [ {nums} ]
  	<br />
  	Mean : {mean}
  	<br />
  	Median : {median}
  	<br />
  	Variance : {variance}
  	<br />
  	Standard Dev : {stddev}
	   <br />
	    Error : {error}

  </code>
</div></div>
    );
  }
}

export default App;
